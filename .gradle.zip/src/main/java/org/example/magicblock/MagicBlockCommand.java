package org.example.magicblock;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;

public class MagicBlockCommand implements CommandExecutor {
    private final MagicBlockPlugin plugin;

    public MagicBlockCommand(MagicBlockPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command can only be run by a player.");
            return true;
        }

        Player player = (Player) sender;

        if (args.length == 0) {
            player.sendMessage(ChatColor.RED + "Usage: /magicblock <get|reload>");
            return true;
        }

        if (args[0].equalsIgnoreCase("get")) {
            if (!player.hasPermission("magicblock.get")) {
                player.sendMessage(ChatColor.RED + "You do not have permission to get a magic block.");
                return true;
            }

            // Create a new ItemStack of WET_SPONGE
            ItemStack magicSponge = new ItemStack(Material.WET_SPONGE);
            ItemMeta spongeMeta = magicSponge.getItemMeta();

            // Set lore for the sponge
            ArrayList<String> lore = new ArrayList<>();
            lore.add(ChatColor.GRAY + "Magicblock");
            if (spongeMeta != null) {
                spongeMeta.setLore(lore);

                // Add a dummy enchantment to give the item a glow
                spongeMeta.addEnchant(Enchantment.DURABILITY, 0, true);
                spongeMeta.addItemFlags(org.bukkit.inventory.ItemFlag.HIDE_ENCHANTS); // Hide the enchantment text

                magicSponge.setItemMeta(spongeMeta);
            }

            // Give the player the modified sponge
            player.getInventory().addItem(magicSponge);
            player.sendMessage(ChatColor.GREEN + "You've received a Magicblock!");
            return true;
        } else if (args[0].equalsIgnoreCase("reload")) {
            if (!player.hasPermission("magicblock.reload")) {
                player.sendMessage(ChatColor.RED + "You do not have permission to reload the plugin.");
                return true;
            }

            plugin.reloadConfig();
            player.sendMessage(ChatColor.GREEN + "MagicBlock configuration reloaded!");
            return true;
        } else {
            player.sendMessage(ChatColor.RED + "Usage: /magicblock <get|reload>");
            return true;
        }
    }
}
