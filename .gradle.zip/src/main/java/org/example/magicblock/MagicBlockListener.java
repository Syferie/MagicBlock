package org.example.magicblock;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.TileState;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.material.MaterialData;

import java.util.*;

import de.tr7zw.nbtapi.NBTItem;
import de.tr7zw.nbtapi.NBTBlock;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

public class MagicBlockListener implements Listener {
    private Map<UUID, Boolean> awaitingInput = new HashMap<>();


    private JavaPlugin plugin;

    public MagicBlockListener(JavaPlugin plugin) {
        this.plugin = plugin;
    }


    // Define the HashSet to track special block locations
    private HashSet<Location> magicLocations = new HashSet<>();
    private List<Material> buildingMaterials;
//材料列表自定义
    public MagicBlockListener(JavaPlugin plugin, List<Material> allowedMaterials) {
        this.plugin = plugin;
        this.buildingMaterials = allowedMaterials;
    }



    private HashMap<UUID, Integer> playerCurrentPage = new HashMap<>();

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent event) {
        ItemStack item = event.getItemInHand();
        ItemMeta meta = item.getItemMeta();
        boolean hasSpecialLore = meta != null && meta.hasLore() && meta.getLore().contains(ChatColor.GRAY + "Magicblock");

        if (hasSpecialLore) {
            // Add the block's location to the set
            magicLocations.add(event.getBlock().getLocation());

            // Make sure the item count doesn't decrease by setting the ItemStack amount to 1
            item.setAmount(1);
            event.getPlayer().getInventory().setItemInMainHand(item);
        }
    }
    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        Location blockLocation = block.getLocation();

        // Check if the block's location is in the HashSet
        if (magicLocations.contains(blockLocation)) {
            // This is our special block, ensure no items drop
            event.setDropItems(false);

            // Remove the block's location from the set
            magicLocations.remove(blockLocation);
        }
    }
    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();

        // Check if the action is a left click and player is sneaking (Shift key pressed)
        if ((event.getAction() == Action.LEFT_CLICK_AIR || event.getAction() == Action.LEFT_CLICK_BLOCK) && player.isSneaking()) {
            ItemStack item = event.getItem();
            if (item != null) {
                ItemMeta meta = item.getItemMeta();
                if (meta != null && meta.hasLore() && meta.getLore().contains(ChatColor.GRAY + "Magicblock")) {
                    // Introduce a delay before opening the GUI
                    new BukkitRunnable() {
                        @Override
                        public void run() {
                            openBlockSelectionGUI(player);
                        }
                    }.runTaskLater(plugin, 2L);  // 1 tick delay
                }
            }
        }
    }


    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        Player player = (Player) event.getWhoClicked();
        UUID playerUUID = player.getUniqueId();
        ItemStack clickedItem = event.getCurrentItem();


        if (event.getView().getTitle().equals(ChatColor.DARK_GRAY + "方块选择")) {
            event.setCancelled(true);


            // Check if the clicked item is the "previous page" button
            if (clickedItem != null && clickedItem.getType() == Material.ARROW && clickedItem.getItemMeta().getDisplayName().equals(ChatColor.GREEN + "上一页")) {
                int currentPage = playerCurrentPage.getOrDefault(playerUUID, 0);
                playerCurrentPage.put(playerUUID, currentPage - 1);
                openBlockSelectionGUI(player);
                return;
            }

            // Check if the clicked item is the "next page" button
            if (clickedItem != null && clickedItem.getType() == Material.ARROW && clickedItem.getItemMeta().getDisplayName().equals(ChatColor.GREEN + "下一页")) {
                int currentPage = playerCurrentPage.getOrDefault(playerUUID, 0);
                playerCurrentPage.put(playerUUID, currentPage + 1);
                openBlockSelectionGUI(player);
                return;
            }

            // Handling block selection
            if (clickedItem != null && buildingMaterials.contains(clickedItem.getType())) {
                // Create a new item stack with the selected type
                ItemStack newItem = new ItemStack(clickedItem.getType());
                ItemMeta meta = newItem.getItemMeta();
                if (meta != null) {
                    // 添加附魔光泽效果
                    meta.addEnchant(Enchantment.DURABILITY, 1, false);
                    meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

                    // 添加Lore
                    List<String> lore = new ArrayList<>();
                    lore.add(ChatColor.GRAY + "Magicblock");
                    meta.setLore(lore);

                    newItem.setItemMeta(meta);
                }

                // Replace the player's held item with the new item
                player.getInventory().setItemInMainHand(newItem);

                // Close the inventory
                player.closeInventory();
                return;
            }

            if (clickedItem != null && clickedItem.getType() == Material.CRAFTING_TABLE && clickedItem.getItemMeta().getDisplayName().equals(ChatColor.YELLOW + "直接替换")) {
                player.closeInventory();
                player.sendMessage(ChatColor.YELLOW + "请输入您想要转换的材料ID（需英文id，不支持中文，大小写无所谓）：");
                // 使用HashMap或其他集合来跟踪需要输入的玩家
                awaitingInput.put(player.getUniqueId(), true);
                return;
            }

        }
    }
    @EventHandler
    public void onItemHeldChange(PlayerItemHeldEvent event) {
        Player player = event.getPlayer();
        UUID playerUUID = player.getUniqueId();
        ItemStack heldItem = player.getInventory().getItem(event.getNewSlot());

        if (awaitingInput.containsKey(playerUUID)) {
            boolean isMagicBlock = false;

            if (heldItem != null) {
                ItemMeta meta = heldItem.getItemMeta();
                isMagicBlock = meta != null && meta.hasLore() && meta.getLore().contains(ChatColor.GRAY + "Magicblock");
            }

            if (!isMagicBlock) {
                awaitingInput.remove(playerUUID);
                player.sendMessage(ChatColor.RED + "由于您切换了物品，输入已被取消。");
                openBlockSelectionGUI(player);
            }
        }
    }





    //    监听玩家说话内容，替换材料
    @EventHandler
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        UUID playerUUID = player.getUniqueId();

        if (awaitingInput.containsKey(playerUUID)) {
            event.setCancelled(true);
            String input = event.getMessage().toUpperCase();
            Material selectedMaterial;
            try {
                selectedMaterial = Material.valueOf(input);
            } catch (IllegalArgumentException e) {
                player.sendMessage(ChatColor.RED + "这不是一个有效的材料名称！");
                return;
            }

            if (buildingMaterials.contains(selectedMaterial)) {
                ItemStack heldItem = player.getInventory().getItemInMainHand();
                ItemStack newItem = new ItemStack(selectedMaterial, heldItem.getAmount());
                ItemMeta meta = newItem.getItemMeta();
                if (meta != null) {
                    // Add enchantment shine
                    meta.addEnchant(Enchantment.DURABILITY, 1, false);
                    meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

                    // Add lore
                    List<String> lore = new ArrayList<>();
                    lore.add(ChatColor.GRAY + "Magicblock");
                    meta.setLore(lore);
                    newItem.setItemMeta(meta);
                }

                // Replace the player's held item
                player.getInventory().setItemInMainHand(newItem);
                player.sendMessage(ChatColor.GREEN + "物品已成功替换！");
                awaitingInput.remove(playerUUID);
            } else {
                player.sendMessage(ChatColor.RED + "这不是一个有效的材料名称！");
            }
        }
    }






    private static final int ITEMS_PER_PAGE = 45; // 5 rows of 9 items each

    private void openBlockSelectionGUI(Player player) {

        int currentPage = playerCurrentPage.getOrDefault(player.getUniqueId(), 0);
        int totalPages = (int) Math.ceil((double) buildingMaterials.size() / ITEMS_PER_PAGE);

        // Create a new inventory with 6 rows (54 slots)
        Inventory inv = Bukkit.createInventory(null, 54, ChatColor.DARK_GRAY + "方块选择");

        // Calculate the start and end indices for the items on this page
        int startIndex = currentPage * ITEMS_PER_PAGE;
        int endIndex = Math.min(startIndex + ITEMS_PER_PAGE, buildingMaterials.size());

        for (int i = startIndex; i < endIndex; i++) {
            inv.addItem(new ItemStack(buildingMaterials.get(i)));
        }

        // Add previous page and next page buttons
        if (currentPage > 0) {
            ItemStack prevPage = new ItemStack(Material.ARROW);
            ItemMeta prevMeta = prevPage.getItemMeta();
            prevMeta.setDisplayName(ChatColor.GREEN + "上一页");
            prevPage.setItemMeta(prevMeta);
            inv.setItem(45, prevPage);
        }
        if (currentPage < totalPages - 1) {
            ItemStack nextPage = new ItemStack(Material.ARROW);
            ItemMeta nextMeta = nextPage.getItemMeta();
            nextMeta.setDisplayName(ChatColor.GREEN + "下一页");
            nextPage.setItemMeta(nextMeta);
            inv.setItem(53, nextPage);
        }

        player.openInventory(inv);
        ItemStack replaceButton = new ItemStack(Material.CRAFTING_TABLE); // 使用工作台图标作为代表
        ItemMeta replaceMeta = replaceButton.getItemMeta();
        replaceMeta.setDisplayName(ChatColor.YELLOW + "直接替换");
        replaceButton.setItemMeta(replaceMeta);
        inv.setItem(49, replaceButton); // 第六行的中间位置是49

    }





    private boolean isMagicSponge(Block block) {
        BlockState state = block.getState();
        if (state instanceof TileState) {
            TileState tileState = (TileState) state;
            MaterialData data = tileState.getData();
            if (state instanceof Nameable) {
                Nameable nameable = (Nameable) state;
                if (nameable.getCustomName() != null && nameable.getCustomName().equals(ChatColor.GOLD + "Magic Sponge")) {
                    // Your code here...
                }
            }
        }
        return false;
    }



}
