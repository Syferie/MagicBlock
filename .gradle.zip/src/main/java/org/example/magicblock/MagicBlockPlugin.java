package org.example.magicblock;

import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;

public class MagicBlockPlugin extends JavaPlugin implements Listener {
    private Material magicBlockMaterial = Material.DIAMOND_BLOCK;  // 默认魔法方块材料

    @Override
    public void onEnable() {

        // 保存默认配置
        saveDefaultConfig();

        // 从配置中读取材料列表
        List<String> allowedMaterialNames = getConfig().getStringList("allowed-materials");
        List<Material> allowedMaterials = new ArrayList<>();
        for (String name : allowedMaterialNames) {
            Material mat = Material.getMaterial(name);
            if (mat != null) {
                allowedMaterials.add(mat);
            } else {
                this.getLogger().warning("Invalid material in config: " + name);
            }
        }

        // 初始化 MagicBlockListener 使用从配置文件中加载的材料列表
        MagicBlockListener listener = new MagicBlockListener(this, allowedMaterials);
        getServer().getPluginManager().registerEvents(listener, this);

        // 其他初始化代码
        this.getCommand("magicblock").setExecutor(new MagicBlockCommand(this));
        this.getCommand("magicblock").setTabCompleter(new MagicBlockTabCompleter());
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        ItemStack item = event.getItem();
        // 检查玩家是否使用魔法方块
        if (item != null && item.getType() == magicBlockMaterial && (event.getAction() == Action.RIGHT_CLICK_BLOCK || event.getAction() == Action.RIGHT_CLICK_AIR)) {
            // 获取玩家选择的方块（这里只是一个简单的示例，您可能需要实现一个GUI或其他机制来让玩家选择）
            Material chosenBlock = Material.STONE;  // 这里只是一个示例，您可以使用任何方块

            // 在玩家的位置放置选择的方块
            event.getPlayer().getWorld().getBlockAt(event.getPlayer().getLocation()).setType(chosenBlock);

            // 防止物品被消耗
            event.setCancelled(true);
        }
    }
}
